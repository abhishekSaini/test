<?php

return [
    'adminEmail' => 'admin@example.com',
    'fromEmail' => 'admin@example.com'
];
