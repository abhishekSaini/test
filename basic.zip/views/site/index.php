<?php

/* @var $this yii\web\View */

$this->title = 'My Application';
?>
<div class="site-index">

    <div class="body-content">

    <div class="jumbotron">
      <p>Content to go here..</p>
    </div>        

    </div>
</div>
